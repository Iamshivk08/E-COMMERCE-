import { useState } from 'react';
import { AuthProvider } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import Header from './components/Header';
import AuthModal from './components/AuthModal';
import HomePage from './pages/HomePage';
import ProductsPage from './pages/ProductsPage';
import ProductDetailPage from './pages/ProductDetailPage';
import CartPage from './pages/CartPage';
import CheckoutPage from './pages/CheckoutPage';
import OrdersPage from './pages/OrdersPage';

type PageType = 'home' | 'products' | 'product' | 'cart' | 'checkout' | 'orders';

function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [selectedId, setSelectedId] = useState<string>('');
  const [showAuthModal, setShowAuthModal] = useState(false);

  const handleNavigate = (page: string, id?: string) => {
    setCurrentPage(page as PageType);
    if (id) setSelectedId(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <AuthProvider>
      <CartProvider>
        <div className="min-h-screen bg-gray-50">
          <Header
            currentPage={currentPage}
            onNavigate={handleNavigate}
            onAuthClick={() => setShowAuthModal(true)}
          />

          {currentPage === 'home' && (
            <HomePage onNavigate={handleNavigate} onAuthClick={() => setShowAuthModal(true)} />
          )}

          {currentPage === 'products' && (
            <ProductsPage
              categoryId={selectedId}
              onNavigate={handleNavigate}
              onAuthClick={() => setShowAuthModal(true)}
            />
          )}

          {currentPage === 'product' && (
            <ProductDetailPage
              productId={selectedId}
              onNavigate={handleNavigate}
              onAuthClick={() => setShowAuthModal(true)}
            />
          )}

          {currentPage === 'cart' && <CartPage onNavigate={handleNavigate} />}

          {currentPage === 'checkout' && <CheckoutPage onNavigate={handleNavigate} />}

          {currentPage === 'orders' && <OrdersPage onNavigate={handleNavigate} />}

          {showAuthModal && <AuthModal onClose={() => setShowAuthModal(false)} />}
        </div>
      </CartProvider>
    </AuthProvider>
  );
}

export default App;
