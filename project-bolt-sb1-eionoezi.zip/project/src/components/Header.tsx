import { ShoppingCart, User, LogOut, Package } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onAuthClick: () => void;
}

export default function Header({ currentPage, onNavigate, onAuthClick }: HeaderProps) {
  const { user, signOut } = useAuth();
  const { totalItems } = useCart();

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <button
              onClick={() => onNavigate('home')}
              className="text-2xl font-bold text-gray-900 hover:text-gray-700 transition-colors"
            >
              ShopHub
            </button>
            <nav className="hidden md:flex gap-6">
              <button
                onClick={() => onNavigate('home')}
                className={`text-sm font-medium transition-colors ${
                  currentPage === 'home' ? 'text-blue-600' : 'text-gray-700 hover:text-gray-900'
                }`}
              >
                Home
              </button>
              <button
                onClick={() => onNavigate('products')}
                className={`text-sm font-medium transition-colors ${
                  currentPage === 'products' ? 'text-blue-600' : 'text-gray-700 hover:text-gray-900'
                }`}
              >
                Products
              </button>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            {user ? (
              <>
                <button
                  onClick={() => onNavigate('orders')}
                  className="flex items-center gap-2 text-gray-700 hover:text-gray-900 transition-colors"
                  title="My Orders"
                >
                  <Package className="w-5 h-5" />
                  <span className="hidden sm:inline text-sm font-medium">Orders</span>
                </button>
                <button
                  onClick={() => onNavigate('cart')}
                  className="flex items-center gap-2 text-gray-700 hover:text-gray-900 transition-colors relative"
                >
                  <ShoppingCart className="w-5 h-5" />
                  {totalItems > 0 && (
                    <span className="absolute -top-2 -right-2 bg-blue-600 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                      {totalItems}
                    </span>
                  )}
                  <span className="hidden sm:inline text-sm font-medium">Cart</span>
                </button>
                <button
                  onClick={() => signOut()}
                  className="flex items-center gap-2 text-gray-700 hover:text-gray-900 transition-colors"
                  title="Sign Out"
                >
                  <LogOut className="w-5 h-5" />
                  <span className="hidden sm:inline text-sm font-medium">Sign Out</span>
                </button>
              </>
            ) : (
              <button
                onClick={onAuthClick}
                className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                <User className="w-5 h-5" />
                <span className="text-sm font-medium">Sign In</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
